"""Azure Container Apps Sandbox Client Library for Python."""

import warnings

from azure.containerapps.sandbox._version import VERSION

__version__ = VERSION

warnings.warn(
    f"azure-containerapps-sandbox ({VERSION}) is experimental and not intended for production use. "
    "APIs may change without notice in future releases.",
    UserWarning,
    stacklevel=2,
)

from azure.containerapps.sandbox._client import SandboxClient
from azure.containerapps.sandbox._mgmt_client import SandboxGroupClient
from azure.containerapps.sandbox._models import (
    AutoDeletePolicy,
    AutoSuspendPolicy,
    CpuUsage,
    DirListing,
    DiskImage,
    DiskImageRef,
    DiskImageSpec,
    DiskImageStatus,
    EgressHostRule,
    EgressPolicy,
    ExecResult,
    FileInfo,
    NetworkUsage,
    PortAuthConfig,
    PortAuthEntraId,
    PublicDiskImage,
    ResourceUsage,
    Sandbox,
    SandboxGroup,
    SandboxLifecyclePolicy,
    SandboxPort,
    SandboxResources,
    SandboxSourcesRef,
    SandboxStats,
    SecretMetadata,
    Snapshot,
    SnapshotRef,
    Volume,
    VolumeUsage,
)

__all__ = [
    "SandboxClient",
    "SandboxGroupClient",
    "__version__",
    # Models
    "AutoDeletePolicy",
    "AutoSuspendPolicy",
    "CpuUsage",
    "DirListing",
    "DiskImage",
    "DiskImageRef",
    "DiskImageSpec",
    "DiskImageStatus",
    "EgressHostRule",
    "EgressPolicy",
    "ExecResult",
    "FileInfo",
    "NetworkUsage",
    "PortAuthConfig",
    "PortAuthEntraId",
    "PublicDiskImage",
    "ResourceUsage",
    "Sandbox",
    "SandboxGroup",
    "SandboxLifecyclePolicy",
    "SandboxPort",
    "SandboxResources",
    "SandboxSourcesRef",
    "SandboxStats",
    "SecretMetadata",
    "Snapshot",
    "SnapshotRef",
    "Volume",
    "VolumeUsage",
]


