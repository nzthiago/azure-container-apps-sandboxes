"""Azure Container Apps Sandbox Groups Management Client — ARM control plane only.

Usage::

    from azure.containerapps.sandbox import SandboxGroupClient

    client = SandboxGroupClient(resource_group="my-rg")
    client.create_group("my-group", location="westus2")
    groups = client.list_groups()
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import httpx
from azure.core.exceptions import ResourceNotFoundError
from azure.identity import DefaultAzureCredential

from azure.containerapps.sandbox._mgmt_helpers import (
    ARM_SCOPE,
    build_headers,
    get_subscription_id,
    log_request,
    raise_for_status,
)

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential

logger = logging.getLogger("azure.containerapps.sandbox")

ARM_BASE = "https://management.azure.com"
API_VERSION = "2026-02-01-preview"


class SandboxGroupClient:
    """Client for Azure Container Apps sandbox groups (ARM control plane).

    :param str resource_group: Default resource group (can be overridden per call).
    :param str subscription_id: Azure subscription ID. Auto-detected from
        ``AZURE_SUBSCRIPTION_ID`` environment variable if omitted.
    :keyword credential: Azure credential for authentication. Defaults to
        ``DefaultAzureCredential()`` which supports az login, managed identity,
        environment variables, and more.
    :paramtype credential: ~azure.core.credentials.TokenCredential

    Example::

        from azure.containerapps.sandbox import SandboxGroupClient

        client = SandboxGroupClient(resource_group="my-rg")
        client.create_group("my-group", location="westus2")
    """

    def __init__(
        self,
        resource_group: str | None = None,
        subscription_id: str | None = None,
        *,
        credential: "TokenCredential | None" = None,
    ):
        self._credential = credential or DefaultAzureCredential()
        self._subscription_id = subscription_id or get_subscription_id()
        self._resource_group = resource_group
        self._arm = httpx.Client(base_url=ARM_BASE, timeout=60.0)

    @property
    def subscription_id(self) -> str:
        """The Azure subscription ID (read-only)."""
        return self._subscription_id

    @property
    def resource_group(self) -> str | None:
        """The default resource group (read-only)."""
        return self._resource_group

    def _rg(self, resource_group: str | None) -> str:
        rg = resource_group or self._resource_group
        if not rg:
            raise ValueError("resource_group required")
        return rg

    # -------------------------------------------------------------------------
    # Internal HTTP
    # -------------------------------------------------------------------------

    def _arm_headers(self) -> dict:
        return build_headers(self._credential, ARM_SCOPE)

    def _arm_get(self, path: str) -> dict:
        log_request("GET", path)
        r = self._arm.get(path, headers=self._arm_headers(), params={"api-version": API_VERSION})
        raise_for_status(r)
        return r.json()

    def _arm_put(self, path: str, body: dict) -> dict:
        log_request("PUT", path)
        r = self._arm.put(path, headers=self._arm_headers(), json=body, params={"api-version": API_VERSION})
        raise_for_status(r)
        return r.json()

    def _arm_delete(self, path: str) -> None:
        log_request("DELETE", path)
        r = self._arm.delete(path, headers=self._arm_headers(), params={"api-version": API_VERSION})
        if r.status_code not in (200, 202, 204):
            raise_for_status(r)

    # -------------------------------------------------------------------------
    # Sandbox Groups ΓÇö ARM control plane (Microsoft.App/sandboxGroups)
    # -------------------------------------------------------------------------

    def _group_base(self, rg: str) -> str:
        return f"/subscriptions/{self.subscription_id}/resourceGroups/{rg}/providers/Microsoft.App/sandboxGroups"

    def list_groups(self, resource_group: str | None = None) -> list[dict]:
        """List sandbox groups. If resource_group is None, lists across entire subscription."""
        if resource_group or self.resource_group:
            rg = self._rg(resource_group)
            path = self._group_base(rg)
        else:
            path = f"/subscriptions/{self.subscription_id}/providers/Microsoft.App/sandboxGroups"
        try:
            result = self._arm_get(path)
            return result.get("value", [])
        except ResourceNotFoundError:
            return []

    def get_group(self, name: str, resource_group: str | None = None) -> dict:
        """Get a sandbox group by name."""
        return self._arm_get(f"{self._group_base(self._rg(resource_group))}/{name}")

    def create_group(
        self,
        name: str,
        location: str,
        resource_group: str | None = None,
        identity: dict | None = None,
        tags: dict | None = None,
        **properties,
    ) -> dict:
        """Create or update a sandbox group.

        :param str name: Sandbox group name.
        :param str location: Azure region (e.g. ``"westus2"``).
        :keyword str resource_group: Override the default resource group.
        :keyword dict identity: Managed identity configuration.
        :keyword dict tags: Azure resource tags.
        :keyword properties: Additional properties for the sandbox group body.
        :returns: Created or updated sandbox group.
        :rtype: dict
        """
        body: dict = {"location": location}
        if identity:
            body["identity"] = identity
        if tags:
            body["tags"] = tags
        if properties:
            body["properties"] = properties
        return self._arm_put(f"{self._group_base(self._rg(resource_group))}/{name}", body)

    def delete_group(self, name: str, resource_group: str | None = None) -> None:
        """Delete a sandbox group."""
        self._arm_delete(f"{self._group_base(self._rg(resource_group))}/{name}")

    def patch_group_identity(self, name: str, identity: dict, resource_group: str | None = None) -> dict:
        """Patch managed identity on a sandbox group.

        :param str name: Sandbox group name.
        :param dict identity: Identity configuration (e.g. ``{"type": "SystemAssigned"}``).
        :keyword str resource_group: Override the default resource group.
        :returns: Updated sandbox group.
        :rtype: dict
        :raises ~azure.core.exceptions.HttpResponseError: On service error.
        """
        path = f"{self._group_base(self._rg(resource_group))}/{name}"
        log_request("PATCH", path)
        r = self._arm.patch(
            path,
            headers=self._arm_headers(),
            json={"identity": identity},
            params={"api-version": API_VERSION},
        )
        raise_for_status(r)
        return r.json()

    # -------------------------------------------------------------------------
    # Context manager / cleanup
    # -------------------------------------------------------------------------

    def close(self) -> None:
        self._arm.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()



