"""Typed response models for the Azure Container Apps Sandbox SDK.

These models mirror the TypeScript SDK interfaces in
``sdks/typescript/azure-containerapps-sandbox/src/models/models.ts``.

All models are constructed from the raw JSON dictionaries returned by
the data-plane API. They provide IDE autocomplete, type safety, and
snake_case property names following Python conventions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ── Sandbox ────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SandboxResources:
    """CPU and memory allocation for a sandbox."""
    cpu: str = ""
    memory: str = ""

    @classmethod
    def _from_dict(cls, d: dict | None) -> SandboxResources | None:
        if not d:
            return None
        return cls(cpu=d.get("cpu", ""), memory=d.get("memory", ""))


@dataclass(frozen=True)
class DiskImageRef:
    """Reference to a disk image used to create a sandbox."""
    name: str | None = None
    id: str | None = None
    is_public: bool | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> DiskImageRef | None:
        if not d:
            return None
        return cls(name=d.get("name"), id=d.get("id"), is_public=d.get("isPublic"))


@dataclass(frozen=True)
class SnapshotRef:
    """Reference to a snapshot used to create a sandbox."""
    id: str = ""

    @classmethod
    def _from_dict(cls, d: dict | None) -> SnapshotRef | None:
        if not d:
            return None
        return cls(id=d.get("id", ""))


@dataclass(frozen=True)
class SandboxSourcesRef:
    """Source reference for sandbox creation (disk image or snapshot)."""
    disk_image: DiskImageRef | None = None
    snapshot: SnapshotRef | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> SandboxSourcesRef | None:
        if not d:
            return None
        return cls(
            disk_image=DiskImageRef._from_dict(d.get("diskImage")),
            snapshot=SnapshotRef._from_dict(d.get("snapshot")),
        )


@dataclass(frozen=True)
class AutoSuspendPolicy:
    """Auto-suspend configuration for sandbox lifecycle."""
    enabled: bool = False
    idle_timeout_seconds: int = 0
    mode: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> AutoSuspendPolicy | None:
        if not d:
            return None
        return cls(
            enabled=d.get("enabled", False),
            idle_timeout_seconds=d.get("idleTimeoutInSeconds", d.get("idleTimeoutSeconds", 0)),
            mode=d.get("mode"),
        )


@dataclass(frozen=True)
class AutoDeletePolicy:
    """Auto-delete configuration for sandbox lifecycle."""
    enabled: bool = False
    idle_timeout_seconds: int | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> AutoDeletePolicy | None:
        if not d:
            return None
        return cls(
            enabled=d.get("enabled", False),
            idle_timeout_seconds=d.get("idleTimeoutInSeconds"),
        )


@dataclass(frozen=True)
class SandboxLifecyclePolicy:
    """Lifecycle policy for a sandbox."""
    auto_suspend: AutoSuspendPolicy | None = None
    auto_delete: AutoDeletePolicy | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> SandboxLifecyclePolicy | None:
        if not d:
            return None
        return cls(
            auto_suspend=AutoSuspendPolicy._from_dict(d.get("autoSuspend")),
            auto_delete=AutoDeletePolicy._from_dict(d.get("autoDelete")),
        )


@dataclass(frozen=True)
class PortAuthEntraId:
    """Entra ID authentication config for a port."""
    enabled: bool = False
    emails: list[str] = field(default_factory=list)

    @classmethod
    def _from_dict(cls, d: dict | None) -> PortAuthEntraId | None:
        if not d:
            return None
        return cls(enabled=d.get("enabled", False), emails=d.get("emails", []))


@dataclass(frozen=True)
class PortAuthConfig:
    """Authentication configuration for a sandbox port."""
    anonymous: bool | None = None
    entra_id: PortAuthEntraId | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> PortAuthConfig | None:
        if not d:
            return None
        return cls(
            anonymous=d.get("anonymous"),
            entra_id=PortAuthEntraId._from_dict(d.get("entraId")),
        )


@dataclass(frozen=True)
class SandboxPort:
    """A port exposed by a sandbox."""
    port: int = 0
    host_port: int | None = None
    protocol: str | None = None
    url: str | None = None
    auth: PortAuthConfig | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> SandboxPort:
        return cls(
            port=d.get("port", 0),
            host_port=d.get("hostPort"),
            protocol=d.get("protocol"),
            url=d.get("url"),
            auth=PortAuthConfig._from_dict(d.get("auth")),
        )


@dataclass(frozen=True)
class EgressHostRule:
    """Simple host-pattern egress rule."""
    pattern: str = ""
    action: str = "Allow"

    @classmethod
    def _from_dict(cls, d: dict) -> EgressHostRule:
        return cls(pattern=d.get("pattern", ""), action=d.get("action", "Allow"))


@dataclass(frozen=True)
class EgressPolicy:
    """Egress policy for a sandbox."""
    default_action: str = "Allow"
    host_rules: list[EgressHostRule] = field(default_factory=list)

    @classmethod
    def _from_dict(cls, d: dict | None) -> EgressPolicy | None:
        if not d:
            return None
        return cls(
            default_action=d.get("defaultAction", "Allow"),
            host_rules=[EgressHostRule._from_dict(r) for r in d.get("hostRules", [])],
        )


@dataclass(frozen=True)
class Sandbox:
    """A sandbox instance returned by get/create operations."""
    id: str = ""
    state: str | None = None
    labels: dict[str, str] = field(default_factory=dict)
    vmm_type: str | None = None
    ports: list[SandboxPort] = field(default_factory=list)
    resources: SandboxResources | None = None
    egress_policy: EgressPolicy | None = None
    environment: dict[str, str] = field(default_factory=dict)
    connections: list[str] = field(default_factory=list)
    sandbox_group_id: str | None = None
    lifecycle: SandboxLifecyclePolicy | None = None
    sources_ref: SandboxSourcesRef | None = None
    preset_sandbox_type: str | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> Sandbox:
        return cls(
            id=d.get("id", ""),
            state=d.get("state"),
            labels=d.get("labels", {}),
            vmm_type=d.get("vmmType"),
            ports=[SandboxPort._from_dict(p) for p in d.get("ports", [])],
            resources=SandboxResources._from_dict(d.get("resources")),
            egress_policy=EgressPolicy._from_dict(d.get("egressPolicy")),
            environment=d.get("environment", {}),
            connections=d.get("connections", []),
            sandbox_group_id=d.get("sandboxGroupId"),
            lifecycle=SandboxLifecyclePolicy._from_dict(d.get("lifecycle")),
            sources_ref=SandboxSourcesRef._from_dict(d.get("sourcesRef")),
            preset_sandbox_type=d.get("presetSandboxType"),
        )


# ── Exec ───────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ExecResult:
    """Result of executing a command in a sandbox."""
    exit_code: int = 0
    stdout: str = ""
    stderr: str = ""

    @classmethod
    def _from_dict(cls, d: dict) -> ExecResult:
        return cls(
            exit_code=d.get("exitCode", 0),
            stdout=d.get("stdout", ""),
            stderr=d.get("stderr", ""),
        )


# ── Disk Images ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class DiskImageStatus:
    """Status of a disk image."""
    state: str = ""
    message: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> DiskImageStatus | None:
        if not d:
            return None
        return cls(state=d.get("state", ""), message=d.get("message"))


@dataclass(frozen=True)
class DiskImageSpec:
    """Container image specification for a disk image."""
    base: str = ""
    entrypoint: list[str] | None = None
    cmd: list[str] | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> DiskImageSpec | None:
        if not d:
            return None
        return cls(base=d.get("base", ""), entrypoint=d.get("entrypoint"), cmd=d.get("cmd"))


@dataclass(frozen=True)
class DiskImage:
    """A disk image resource."""
    id: str = ""
    labels: dict[str, str] = field(default_factory=dict)
    image: DiskImageSpec | None = None
    status: DiskImageStatus | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> DiskImage:
        return cls(
            id=d.get("id", ""),
            labels=d.get("labels", {}),
            image=DiskImageSpec._from_dict(d.get("image")),
            status=DiskImageStatus._from_dict(d.get("status")),
        )


@dataclass(frozen=True)
class PublicDiskImage:
    """A public disk image."""
    name: str = ""
    status: DiskImageStatus | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> PublicDiskImage:
        return cls(
            name=d.get("name", ""),
            status=DiskImageStatus._from_dict(d.get("status")),
        )


# ── Snapshots ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class Snapshot:
    """A sandbox snapshot."""
    id: str = ""
    labels: dict[str, str] = field(default_factory=dict)
    sandbox_id: str | None = None
    status: str | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> Snapshot:
        return cls(
            id=d.get("id", ""),
            labels=d.get("labels", {}),
            sandbox_id=d.get("sandboxId"),
            status=d.get("status"),
        )


# ── Volumes ────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class VolumeUsage:
    """Volume usage information."""
    used: str | None = None
    available: str | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> VolumeUsage | None:
        if not d:
            return None
        return cls(used=d.get("used"), available=d.get("available"))


@dataclass(frozen=True)
class Volume:
    """A volume resource."""
    name: str = ""
    type: str | None = None
    labels: dict[str, str] = field(default_factory=dict)
    size: str | None = None
    usage: VolumeUsage | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> Volume:
        return cls(
            name=d.get("volumeName", d.get("name", "")),
            type=d.get("type"),
            labels=d.get("labels", {}),
            size=d.get("size"),
            usage=VolumeUsage._from_dict(d.get("usage")),
        )


# ── Files ──────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class FileInfo:
    """Information about a file or directory."""
    name: str = ""
    path: str = ""
    size: int | None = None
    is_directory: bool = False
    modified_at: str | None = None
    mode: str | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> FileInfo:
        return cls(
            name=d.get("name", ""),
            path=d.get("path", ""),
            size=d.get("size"),
            is_directory=d.get("isDirectory", False),
            modified_at=d.get("modifiedAt"),
            mode=d.get("mode"),
        )


@dataclass(frozen=True)
class DirListing:
    """Directory listing result."""
    path: str = ""
    entries: list[FileInfo] = field(default_factory=list)

    @classmethod
    def _from_dict(cls, d: dict) -> DirListing:
        return cls(
            path=d.get("path", ""),
            entries=[FileInfo._from_dict(e) for e in d.get("entries", [])],
        )


# ── Stats ──────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ResourceUsage:
    """Memory or storage usage."""
    used_bytes: int | None = None
    total_bytes: int | None = None
    available_bytes: int | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> ResourceUsage | None:
        if not d:
            return None
        return cls(
            used_bytes=d.get("usedBytes"),
            total_bytes=d.get("totalBytes"),
            available_bytes=d.get("availableBytes"),
        )


@dataclass(frozen=True)
class CpuUsage:
    """CPU usage stats."""
    usage_nano_cores: int | None = None
    usage_core_nano_seconds: int | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> CpuUsage | None:
        if not d:
            return None
        return cls(
            usage_nano_cores=d.get("usageNanoCores"),
            usage_core_nano_seconds=d.get("usageCoreNanoSeconds"),
        )


@dataclass(frozen=True)
class NetworkUsage:
    """Network usage stats."""
    rx_bytes: int | None = None
    tx_bytes: int | None = None

    @classmethod
    def _from_dict(cls, d: dict | None) -> NetworkUsage | None:
        if not d:
            return None
        return cls(rx_bytes=d.get("rxBytes"), tx_bytes=d.get("txBytes"))


@dataclass(frozen=True)
class SandboxStats:
    """Resource usage statistics for a sandbox."""
    cpu: CpuUsage | None = None
    memory: ResourceUsage | None = None
    storage: ResourceUsage | None = None
    network: NetworkUsage | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> SandboxStats:
        return cls(
            cpu=CpuUsage._from_dict(d.get("cpu")),
            memory=ResourceUsage._from_dict(d.get("memory")),
            storage=ResourceUsage._from_dict(d.get("storage")),
            network=NetworkUsage._from_dict(d.get("network")),
        )


# ── Secrets ────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SecretMetadata:
    """Metadata about a secret."""
    id: str = ""
    keys: list[str] = field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None

    @classmethod
    def _from_dict(cls, d: dict) -> SecretMetadata:
        return cls(
            id=d.get("id", ""),
            keys=d.get("keys", []),
            created_at=d.get("createdAt"),
            updated_at=d.get("updatedAt"),
        )


# ── Sandbox Group (ARM) ───────────────────────────────────────────────────


@dataclass(frozen=True)
class SandboxGroup:
    """A sandbox group resource (ARM)."""
    id: str | None = None
    name: str = ""
    location: str = ""
    tags: dict[str, str] = field(default_factory=dict)
    properties: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def _from_dict(cls, d: dict) -> SandboxGroup:
        return cls(
            id=d.get("id"),
            name=d.get("name", ""),
            location=d.get("location", ""),
            tags=d.get("tags", {}),
            properties=d.get("properties", {}),
        )
