"""Shared helpers ΓÇö token acquisition, headers, error mapping.

Uses ``azure-identity`` for authentication.
Falls back to ``az`` CLI for subscription ID detection.
Maps ``httpx`` transport errors to ``azure.core.exceptions``.
"""

from __future__ import annotations

import logging
import os
import platform
import uuid
from typing import TYPE_CHECKING

import httpx
from azure.core.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ResourceNotFoundError,
)

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential

logger = logging.getLogger("azure.containerapps.sandbox")

_VERSION = "0.1.0b1"
_USER_AGENT = (
    f"azsdk-python-containerapps-sandbox/{_VERSION} "
    f"Python/{platform.python_version()}"
)

ARM_SCOPE = "https://management.azure.com/.default"


def get_token(credential: "TokenCredential", scope: str) -> str:
    """Acquire a bearer token via the supplied credential.

    :param credential: An ``azure-identity`` credential instance.
    :param str scope: The OAuth scope to request.
    :returns: A bearer token string.
    :rtype: str
    :raises ~azure.core.exceptions.ClientAuthenticationError:
        If the credential cannot produce a token.
    """
    try:
        return credential.get_token(scope).token
    except Exception as exc:
        raise ClientAuthenticationError(
            message=f"Failed to acquire token for scope '{scope}'. "
            "Ensure you are logged in (az login) or that your credential is configured.",
            error=exc,
        ) from exc


def get_subscription_id() -> str:
    """Detect subscription ID from environment or Azure CLI.

    Checks ``AZURE_SUBSCRIPTION_ID`` environment variable first,
    then falls back to ``az account show`` if Azure CLI is available.

    :returns: The Azure subscription ID.
    :rtype: str
    :raises ValueError: If subscription cannot be determined.
    """
    sub = os.environ.get("AZURE_SUBSCRIPTION_ID")
    if sub:
        return sub

    # Fallback: try Azure CLI
    try:
        import subprocess
        result = subprocess.run(
            "az account show --query id -o tsv",
            capture_output=True, text=True, check=True, shell=True,
        )
        sub = result.stdout.strip()
        if sub:
            return sub
    except Exception:
        pass

    raise ValueError(
        "subscription_id is required. Pass it to the constructor, set "
        "the AZURE_SUBSCRIPTION_ID environment variable, or run 'az login'."
    )


def build_headers(
    credential: "TokenCredential",
    scope: str,
    *,
    content_type: str = "application/json",
) -> dict[str, str]:
    """Build HTTP headers with auth, user-agent, and request tracing.

    :param credential: An ``azure-identity`` credential instance.
    :param str scope: OAuth scope for the bearer token.
    :keyword str content_type: Content-Type header value.
    :returns: Headers dict.
    :rtype: dict[str, str]
    """
    headers = {
        "Authorization": f"Bearer {get_token(credential, scope)}",
        "Content-Type": content_type,
        "User-Agent": _USER_AGENT,
        "x-ms-client-request-id": str(uuid.uuid4()),
    }
    return headers


def raise_for_status(response: httpx.Response) -> None:
    """Raise an ``azure.core.exceptions`` error for non-success responses.

    :param response: The httpx response to check.
    :raises ~azure.core.exceptions.ResourceNotFoundError: For 404 responses.
    :raises ~azure.core.exceptions.ClientAuthenticationError: For 401/403 responses.
    :raises ~azure.core.exceptions.HttpResponseError: For other non-success responses.
    """
    if response.is_success:
        return

    status = response.status_code
    try:
        detail = response.json()
    except Exception:
        detail = response.text

    message = f"({status}) {detail}"

    if status == 404:
        raise ResourceNotFoundError(message=message)
    if status in (401, 403):
        raise ClientAuthenticationError(message=message)
    raise HttpResponseError(message=message, response=None)


def log_request(method: str, url: str) -> None:
    """Log an outbound HTTP request at DEBUG level."""
    logger.debug("Request: %s %s", method, url)


def log_error(method: str, url: str, status: int) -> None:
    """Log an HTTP error at WARNING level."""
    logger.warning("Error: %s %s -> %d", method, url, status)
