"""Azure Sandbox data-plane client.

Usage::

    from azure.containerapps.sandbox import SandboxClient

    client = SandboxClient(resource_group="my-rg")

    sbx = client.create_sandbox("my-group", disk="ubuntu")
    print(sbx.id, sbx.state)
    result = client.exec(sbx.id, "my-group", "echo hello")
    print(result.exit_code, result.stdout)
    client.delete_sandbox(sbx.id, "my-group")

Authentication uses ``DefaultAzureCredential`` from ``azure-identity``, which
automatically picks up ``az login``, managed identity, environment variables, etc.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import httpx
from azure.identity import DefaultAzureCredential

from azure.containerapps.sandbox._helpers import (
    DATA_PLANE_SCOPE,
    build_headers,
    get_subscription_id,
    get_token,
    log_error,
    log_request,
    raise_for_status,
)
from azure.containerapps.sandbox._models import (
    DiskImage,
    ExecResult,
    PublicDiskImage,
    Sandbox,
    SandboxStats,
    Snapshot,
    Volume,
)

if TYPE_CHECKING:
    from azure.core.credentials import TokenCredential

logger = logging.getLogger("azure.containerapp.sandbox")

DATA_PLANE_BASE = "https://management.azuredevcompute.io"


class SandboxClient:
    """Data-plane client for Azure Container Apps sandboxes.

    :param str resource_group: Default resource group (can be overridden per call).
    :param str subscription_id: Azure subscription ID. Auto-detected from
        ``AZURE_SUBSCRIPTION_ID`` environment variable if omitted.
    :keyword credential: Azure credential for authentication. Defaults to
        ``DefaultAzureCredential()`` which supports az login, managed identity,
        environment variables, and more.
    :paramtype credential: ~azure.core.credentials.TokenCredential

    Example::

        from azure.containerapps.sandbox import SandboxClient

        client = SandboxClient(resource_group="my-rg")

        sbx = client.create_sandbox("my-group", disk="ubuntu")
        result = client.exec(sbx["id"], "my-group", "echo hello")
        client.delete_sandbox(sbx["id"], "my-group")
    """

    def __init__(
        self,
        resource_group: str | None = None,
        subscription_id: str | None = None,
        *,
        credential: "TokenCredential | None" = None,
    ):
        self._credential = credential or DefaultAzureCredential()
        self._subscription_id = subscription_id or get_subscription_id()
        self._resource_group = resource_group
        self._dp = httpx.Client(base_url=DATA_PLANE_BASE, timeout=300.0)

    @property
    def subscription_id(self) -> str:
        """The Azure subscription ID (read-only)."""
        return self._subscription_id

    @property
    def resource_group(self) -> str | None:
        """The default resource group (read-only)."""
        return self._resource_group

    def _rg(self, resource_group: str | None) -> str:
        rg = resource_group or self._resource_group
        if not rg:
            raise ValueError("resource_group required")
        return rg

    # -------------------------------------------------------------------------
    # Internal HTTP
    # -------------------------------------------------------------------------

    def _dp_headers(self) -> dict:
        return build_headers(self._credential, DATA_PLANE_SCOPE)

    def _dp_get(self, path: str) -> dict | list:
        log_request("GET", path)
        r = self._dp.get(path, headers=self._dp_headers())
        raise_for_status(r)
        return r.json() if r.status_code != 204 else {}

    def _dp_put(self, path: str, body: dict) -> dict:
        log_request("PUT", path)
        r = self._dp.put(path, headers=self._dp_headers(), json=body)
        raise_for_status(r)
        return r.json()

    def _dp_post(self, path: str, body: dict | None = None) -> dict:
        log_request("POST", path)
        headers = self._dp_headers()
        if body is None:
            r = self._dp.post(path, headers=headers)
        else:
            r = self._dp.post(path, headers=headers, json=body)
        raise_for_status(r)
        return r.json() if r.status_code != 204 else {}

    def _dp_delete(self, path: str) -> None:
        log_request("DELETE", path)
        r = self._dp.delete(path, headers=self._dp_headers())
        if r.status_code not in (200, 202, 204):
            raise_for_status(r)

    # -------------------------------------------------------------------------
    # Sandboxes — data plane
    # -------------------------------------------------------------------------

    def _sbx_base(self, sandbox_group: str, rg: str) -> str:
        return f"/subscriptions/{self.subscription_id}/resourceGroups/{rg}/sandboxGroups/{sandbox_group}/sandboxes"

    def _sbx_path(self, sandbox_id: str, sandbox_group: str, rg: str) -> str:
        return f"{self._sbx_base(sandbox_group, rg)}/{sandbox_id}"

    def list_sandboxes(self, sandbox_group: str, resource_group: str | None = None) -> list[Sandbox]:
        """List sandboxes in a sandbox group."""
        raw = self._dp_get(self._sbx_base(sandbox_group, self._rg(resource_group)))
        return [Sandbox._from_dict(s) for s in raw] if isinstance(raw, list) else []

    def get_sandbox(self, sandbox_id: str, sandbox_group: str, resource_group: str | None = None) -> Sandbox:
        """Get a sandbox by ID."""
        return Sandbox._from_dict(self._dp_get(self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))))

    def create_sandbox(
        self,
        sandbox_group: str,
        disk: str | None = "ubuntu",
        disk_id: str | None = None,
        snapshot_id: str | None = None,
        preset: str | None = None,
        cpu: str = "1000m",
        memory: str = "2048Mi",
        auto_suspend_seconds: int = 300,
        labels: dict[str, str] | None = None,
        environment: dict[str, str] | None = None,
        connections: list[str] | None = None,
        gateway_connections: list[dict] | None = None,
        egress_policy: dict | None = None,
        volumes: list[dict] | None = None,
        ports: list[dict] | None = None,
        resource_group: str | None = None,
        entrypoint: list[str] | None = None,
        cmd: list[str] | None = None,
        skip_egress_proxy: bool | None = None,
        agent_identity: dict | None = None,
        telemetry_config: dict | None = None,
        content_package_downloads: list[dict] | None = None,
        vmm_type: str | None = None,
    ) -> Sandbox:
        """Create a sandbox.

        Sources (pick one):
          disk — public disk image name (default: "ubuntu")
          disk_id — private disk image ID
          snapshot_id — create from a snapshot
          preset — preset sandbox type (e.g., "copilot")
        """
        body: dict = {}

        # Source
        if preset:
            body["presetSandboxType"] = preset
        elif snapshot_id:
            # Snapshot creates: only sourcesRef is allowed — server rejects lifecycle/resources/etc.
            body["sourcesRef"] = {"snapshot": {"id": snapshot_id}}
            return Sandbox._from_dict(self._dp_put(self._sbx_base(sandbox_group, self._rg(resource_group)), body))
        elif disk_id:
            body["sourcesRef"] = {"diskImage": {"id": disk_id}}
        else:
            body["sourcesRef"] = {"diskImage": {"name": disk or "ubuntu", "isPublic": True}}

        # Resources (skip for presets and snapshots — they have their own defaults)
        if not preset and not snapshot_id:
            body["resources"] = {"cpu": cpu, "memory": memory}

        # Lifecycle
        body["lifecycle"] = {
            "autoSuspend": {"enabled": True, "idleTimeoutSeconds": auto_suspend_seconds, "mode": "Memory"}
        }

        if labels:
            body["labels"] = labels
        if environment:
            body["environment"] = environment
        if connections:
            body["connections"] = connections
        if gateway_connections:
            body["gatewayConnections"] = gateway_connections
        if egress_policy:
            body["egressPolicy"] = egress_policy
        if volumes:
            body["volumes"] = volumes
        if ports:
            body["ports"] = [
                {"port": p} if isinstance(p, int) else p for p in ports
            ]
        if entrypoint:
            body["entrypoint"] = entrypoint
        if cmd:
            body["cmd"] = cmd
        if skip_egress_proxy is not None:
            body["skipEgressProxy"] = skip_egress_proxy
        if agent_identity:
            body["agentIdentity"] = agent_identity
        if telemetry_config:
            body["telemetryConfig"] = telemetry_config
        if content_package_downloads:
            body["contentPackageDownloads"] = content_package_downloads
        if vmm_type:
            body["vmmType"] = vmm_type

        return Sandbox._from_dict(self._dp_put(self._sbx_base(sandbox_group, self._rg(resource_group)), body))

    def delete_sandbox(self, sandbox_id: str, sandbox_group: str, resource_group: str | None = None) -> None:
        """Delete a sandbox."""
        self._dp_delete(self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group)))

    # --- Lifecycle ---

    def stop_sandbox(self, sandbox_id: str, sandbox_group: str, resource_group: str | None = None) -> None:
        """Stop (suspend) a sandbox."""
        self._dp_post(f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/stop")

    def resume_sandbox(self, sandbox_id: str, sandbox_group: str, resource_group: str | None = None) -> None:
        """Resume a suspended sandbox."""
        self._dp_post(f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/resume")

    # --- Exec ---

    def exec(self, sandbox_id: str, sandbox_group: str, command: str,
             working_directory: str | None = None,
             resource_group: str | None = None) -> ExecResult:
        """Execute a shell command. Returns :class:`ExecResult` with exit_code, stdout, stderr."""
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/executeShellCommand"
        body: dict = {"command": command}
        if working_directory:
            body["workingDirectory"] = working_directory
        return ExecResult._from_dict(self._dp_post(path, body))

    # --- Ports ---

    def add_port(self, sandbox_id: str, sandbox_group: str, port: int,
                 anonymous: bool = False, email: str | None = None,
                 resource_group: str | None = None) -> dict:
        """Add a port to a sandbox."""
        body: dict = {"port": port}
        if anonymous:
            body["auth"] = {"anonymous": True}
        elif email:
            body["auth"] = {"entraId": {"enabled": True, "emails": [email]}}
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/ports/add"
        return self._dp_post(path, body)

    def remove_port(self, sandbox_id: str, sandbox_group: str, port: int, resource_group: str | None = None) -> None:
        """Remove a port."""
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/ports/remove"
        self._dp_post(path, {"port": port})

    def update_ports(self, sandbox_id: str, sandbox_group: str, ports: list[dict],
                     resource_group: str | None = None) -> list[dict]:
        """Replace all port mappings on a sandbox."""
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/ports"
        return self._dp_put(path, {"ports": ports})

    # --- Snapshot ---

    def create_snapshot(self, sandbox_id: str, sandbox_group: str,
                        name: str | None = None, resource_group: str | None = None) -> Snapshot:
        """Create a snapshot of a sandbox."""
        body = {"labels": {"name": name}} if name else {}
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/snapshot"
        return Snapshot._from_dict(self._dp_post(path, body))

    # --- Stats ---

    def get_stats(self, sandbox_id: str, sandbox_group: str, resource_group: str | None = None) -> SandboxStats:
        """Get sandbox resource stats."""
        return SandboxStats._from_dict(self._dp_get(f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/stats"))

    # --- Egress ---

    def set_egress_policy(self, sandbox_id: str, sandbox_group: str, policy: dict,
                          resource_group: str | None = None) -> dict:
        """Set full egress policy (raw). For convenience methods, see below."""
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/egresspolicy"
        return self._dp_post(path, policy)

    def get_egress_policy(self, sandbox_id: str, sandbox_group: str,
                          resource_group: str | None = None) -> dict:
        """Get current egress policy."""
        raw = self._dp_get(self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group)))
        return raw.get("egressPolicy") or {"defaultAction": "Allow"}

    def set_egress_default(self, sandbox_id: str, sandbox_group: str,
                           action: str = "Deny", resource_group: str | None = None) -> dict:
        """Set default egress action (Allow or Deny)."""
        policy = self.get_egress_policy(sandbox_id, sandbox_group, resource_group)
        policy["defaultAction"] = action
        return self.set_egress_policy(sandbox_id, sandbox_group, policy, resource_group)

    def add_egress_host_rule(self, sandbox_id: str, sandbox_group: str,
                             pattern: str, action: str = "Allow",
                             resource_group: str | None = None) -> dict:
        """Add a host allow/deny rule (e.g., '*.github.com')."""
        policy = self.get_egress_policy(sandbox_id, sandbox_group, resource_group)
        if "hostRules" not in policy:
            policy["hostRules"] = []
        policy["hostRules"].append({"pattern": pattern, "action": action})
        return self.set_egress_policy(sandbox_id, sandbox_group, policy, resource_group)

    def add_egress_transform_rule(self, sandbox_id: str, sandbox_group: str,
                                  host: str, headers: list[dict],
                                  name: str | None = None,
                                  path: str | None = None,
                                  methods: list[str] | None = None,
                                  resource_group: str | None = None) -> dict:
        """Add a Transform rule that modifies headers on outbound requests.

        headers: list of {"operation": "Set"|"Append"|"Remove", "name": "...", "value": "..."}
        """
        policy = self.get_egress_policy(sandbox_id, sandbox_group, resource_group)
        if not policy.get("rules"):
            policy["rules"] = []
        rule: dict = {
            "match": {"host": host},
            "action": {"type": "Transform", "headers": headers},
        }
        if name:
            rule["name"] = name
        if path:
            rule["match"]["path"] = path
        if methods:
            rule["match"]["methods"] = methods
        policy["rules"].append(rule)
        return self.set_egress_policy(sandbox_id, sandbox_group, policy, resource_group)

    def add_egress_rewrite_rule(self, sandbox_id: str, sandbox_group: str,
                                host: str, rewrite_host: str | None = None,
                                rewrite_path: str | None = None,
                                rewrite_scheme: str | None = None,
                                headers: list[dict] | None = None,
                                name: str | None = None,
                                resource_group: str | None = None) -> dict:
        """Add a Rewrite rule that changes the destination of outbound requests."""
        policy = self.get_egress_policy(sandbox_id, sandbox_group, resource_group)
        if not policy.get("rules"):
            policy["rules"] = []
        action: dict = {"type": "Rewrite"}
        if rewrite_host:
            action["host"] = rewrite_host
        if rewrite_path:
            action["path"] = rewrite_path
        if rewrite_scheme:
            action["scheme"] = rewrite_scheme
        if headers:
            action["headers"] = headers
        rule: dict = {"match": {"host": host}, "action": action}
        if name:
            rule["name"] = name
        policy["rules"].append(rule)
        return self.set_egress_policy(sandbox_id, sandbox_group, policy, resource_group)

    def get_egress_decisions(self, sandbox_id: str, sandbox_group: str,
                             resource_group: str | None = None) -> dict:
        """Get egress decision audit log."""
        return self._dp_get(f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/egress-decisions")

    # --- Lifecycle policy ---

    def set_lifecycle_policy(self, sandbox_id: str, sandbox_group: str, policy: dict,
                             resource_group: str | None = None) -> dict:
        """Set lifecycle policy (auto-suspend, auto-delete)."""
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/lifecycle"
        return self._dp_post(path, policy)

    # --- Commit (save sandbox as disk image) ---

    def commit_sandbox(self, sandbox_id: str, sandbox_group: str,
                       name: str | None = None, resource_group: str | None = None) -> dict:
        """Commit sandbox state as a new disk image."""
        body = {"labels": {"name": name}} if name else {}
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/commit"
        return self._dp_post(path, body)

    # --- Volume mount ---

    def add_volume_mount(self, sandbox_id: str, sandbox_group: str, volume_mount: dict,
                         resource_group: str | None = None) -> None:
        """Add a volume mount to a sandbox."""
        path = f"{self._sbx_path(sandbox_id, sandbox_group, self._rg(resource_group))}/volumes/add"
        self._dp_post(path, volume_mount)

    # -------------------------------------------------------------------------
    # Files — data plane
    # -------------------------------------------------------------------------

    def _files_base(self, sandbox_id: str, sandbox_group: str, rg: str) -> str:
        return f"{self._sbx_path(sandbox_id, sandbox_group, rg)}/files"

    def list_files(self, sandbox_id: str, sandbox_group: str, path: str = "/",
                   container_name: str | None = None,
                   resource_group: str | None = None) -> dict:
        """List directory contents in a sandbox."""
        base = self._files_base(sandbox_id, sandbox_group, self._rg(resource_group))
        params: dict = {"path": path}
        if container_name:
            params["containerName"] = container_name
        log_request("GET", f"{base}/list")
        r = self._dp.get(f"{base}/list", headers=self._dp_headers(), params=params)
        raise_for_status(r)
        return r.json()

    def stat_file(self, sandbox_id: str, sandbox_group: str, path: str,
                  container_name: str | None = None,
                  resource_group: str | None = None) -> dict:
        """Get file/directory metadata."""
        base = self._files_base(sandbox_id, sandbox_group, self._rg(resource_group))
        params: dict = {"path": path}
        if container_name:
            params["containerName"] = container_name
        log_request("GET", f"{base}/stat")
        r = self._dp.get(f"{base}/stat", headers=self._dp_headers(), params=params)
        raise_for_status(r)
        return r.json()

    def read_file(self, sandbox_id: str, sandbox_group: str, path: str,
                  container_name: str | None = None,
                  resource_group: str | None = None) -> bytes:
        """Read a file from a sandbox (returns bytes)."""
        base = self._files_base(sandbox_id, sandbox_group, self._rg(resource_group))
        headers = self._dp_headers()
        del headers["Content-Type"]
        params: dict = {"path": path}
        if container_name:
            params["containerName"] = container_name
        log_request("GET", base)
        r = self._dp.get(base, headers=headers, params=params)
        raise_for_status(r)
        return r.content

    def write_file(self, sandbox_id: str, sandbox_group: str, path: str,
                   content: str | bytes, create_dirs: bool = True,
                   mode: str | None = None,
                   container_name: str | None = None,
                   resource_group: str | None = None) -> None:
        """Write a file to a sandbox."""
        base = self._files_base(sandbox_id, sandbox_group, self._rg(resource_group))
        headers = self._dp_headers()
        headers["Content-Type"] = "application/octet-stream"
        data = content.encode("utf-8") if isinstance(content, str) else content
        params: dict = {"path": path, "createDirs": str(create_dirs).lower()}
        if mode:
            params["mode"] = mode
        if container_name:
            params["containerName"] = container_name
        log_request("PUT", base)
        r = self._dp.put(base, headers=headers, content=data, params=params)
        raise_for_status(r)

    def delete_file(self, sandbox_id: str, sandbox_group: str, path: str,
                    recursive: bool = False,
                    container_name: str | None = None,
                    resource_group: str | None = None) -> None:
        """Delete a file or directory from a sandbox."""
        base = self._files_base(sandbox_id, sandbox_group, self._rg(resource_group))
        params: dict = {"path": path, "recursive": str(recursive).lower()}
        if container_name:
            params["containerName"] = container_name
        log_request("DELETE", base)
        r = self._dp.delete(base, headers=self._dp_headers(), params=params)
        if r.status_code not in (200, 204):
            raise_for_status(r)

    def mkdir(self, sandbox_id: str, sandbox_group: str, path: str,
              container_name: str | None = None,
              resource_group: str | None = None) -> None:
        """Create a directory in a sandbox."""
        base = self._files_base(sandbox_id, sandbox_group, self._rg(resource_group))
        params: dict = {}
        if container_name:
            params["containerName"] = container_name
        log_request("POST", f"{base}/mkdir")
        r = self._dp.post(f"{base}/mkdir", headers=self._dp_headers(),
                          json={"path": path}, params=params)
        raise_for_status(r)

    # -------------------------------------------------------------------------
    # Disk Images — data plane (group-scoped)
    # -------------------------------------------------------------------------

    def _image_base(self, sandbox_group: str, rg: str) -> str:
        return (f"/subscriptions/{self.subscription_id}/resourceGroups/{rg}"
                f"/sandboxGroups/{sandbox_group}/diskimages")

    def list_disk_images(self, sandbox_group: str, resource_group: str | None = None) -> list[DiskImage]:
        """List private disk images in a sandbox group."""
        raw = self._dp_get(self._image_base(sandbox_group, self._rg(resource_group)))
        return [DiskImage._from_dict(d) for d in raw] if isinstance(raw, list) else []

    def list_public_disk_images(self) -> list[PublicDiskImage]:
        """List public disk images available to all sandbox groups."""
        raw = self._dp_get("/public/diskimages")
        return [PublicDiskImage._from_dict(d) for d in raw] if isinstance(raw, list) else []

    def get_disk_image(self, image_id: str, sandbox_group: str,
                       resource_group: str | None = None) -> DiskImage:
        """Get a disk image by ID."""
        return DiskImage._from_dict(self._dp_get(f"{self._image_base(sandbox_group, self._rg(resource_group))}/{image_id}"))

    def create_disk_image(self, sandbox_group: str, base_image: str, name: str | None = None,
                          entrypoint: list[str] | None = None,
                          cmd: list[str] | None = None,
                          registry_credentials: dict | None = None,
                          managed_identity_resource_id: str | None = None,
                          resource_group: str | None = None) -> DiskImage:
        """Create a disk image from a container image."""
        body: dict = {"image": {"base": base_image}}
        if entrypoint:
            body["image"]["entrypoint"] = entrypoint
        if cmd:
            body["image"]["cmd"] = cmd
        if name:
            body["labels"] = {"name": name}
        if registry_credentials:
            body["registryCredentials"] = registry_credentials
        if managed_identity_resource_id:
            body["managedIdentityResourceId"] = managed_identity_resource_id
        return DiskImage._from_dict(self._dp_put(self._image_base(sandbox_group, self._rg(resource_group)), body))

    def delete_disk_image(self, image_id: str, sandbox_group: str,
                          resource_group: str | None = None) -> None:
        """Delete a disk image."""
        self._dp_delete(f"{self._image_base(sandbox_group, self._rg(resource_group))}/{image_id}")

    # -------------------------------------------------------------------------
    # Snapshots — data plane (group-scoped)
    # -------------------------------------------------------------------------

    def _snapshot_base(self, sandbox_group: str, rg: str) -> str:
        return (f"/subscriptions/{self.subscription_id}/resourceGroups/{rg}"
                f"/sandboxGroups/{sandbox_group}/snapshots")

    def list_snapshots(self, sandbox_group: str, resource_group: str | None = None) -> list[Snapshot]:
        """List snapshots in a sandbox group."""
        raw = self._dp_get(self._snapshot_base(sandbox_group, self._rg(resource_group)))
        return [Snapshot._from_dict(s) for s in raw] if isinstance(raw, list) else []

    def get_snapshot(self, snapshot_id: str, sandbox_group: str,
                     resource_group: str | None = None) -> Snapshot:
        """Get a snapshot by ID."""
        return Snapshot._from_dict(self._dp_get(f"{self._snapshot_base(sandbox_group, self._rg(resource_group))}/{snapshot_id}"))

    def delete_snapshot(self, snapshot_id: str, sandbox_group: str,
                        resource_group: str | None = None) -> None:
        """Delete a snapshot."""
        self._dp_delete(f"{self._snapshot_base(sandbox_group, self._rg(resource_group))}/{snapshot_id}")

    # -------------------------------------------------------------------------
    # Volumes — data plane (group-scoped)
    # -------------------------------------------------------------------------

    def _volume_base(self, sandbox_group: str, rg: str) -> str:
        return (f"/subscriptions/{self.subscription_id}/resourceGroups/{rg}"
                f"/sandboxGroups/{sandbox_group}/volumes")

    def list_volumes(self, sandbox_group: str, resource_group: str | None = None) -> list[Volume]:
        """List volumes in a sandbox group."""
        raw = self._dp_get(self._volume_base(sandbox_group, self._rg(resource_group)))
        return [Volume._from_dict(v) for v in raw] if isinstance(raw, list) else []

    def get_volume(self, volume_name: str, sandbox_group: str,
                   resource_group: str | None = None) -> Volume:
        """Get a volume by name."""
        return Volume._from_dict(self._dp_get(f"{self._volume_base(sandbox_group, self._rg(resource_group))}/{volume_name}"))

    def create_volume(self, sandbox_group: str, name: str, size: str | None = None,
                      type: str = "AzureBlob",
                      labels: dict | None = None,
                      resource_group: str | None = None) -> Volume:
        """Create a volume.

        :param str type: Volume type — ``"AzureBlob"`` or ``"DataDisk"``.
        :param str size: Disk size (e.g. ``"1Gi"``). Required for DataDisk, ignored for AzureBlob.
        """
        body: dict = {"type": type}
        if size:
            body["size"] = size
        if labels and len(labels) > 0:
            body["labels"] = labels
        return Volume._from_dict(self._dp_put(f"{self._volume_base(sandbox_group, self._rg(resource_group))}/{name}", body))

    def delete_volume(self, volume_name: str, sandbox_group: str,
                      resource_group: str | None = None) -> None:
        """Delete a volume."""
        self._dp_delete(f"{self._volume_base(sandbox_group, self._rg(resource_group))}/{volume_name}")

    # -------------------------------------------------------------------------
    # Secrets — data plane (user-scoped, flat path)
    # -------------------------------------------------------------------------

    def list_secrets(self) -> list:
        """List all secrets for the current user."""
        result = self._dp_get("/secrets")
        if isinstance(result, dict):
            return result.get("secrets", [])
        return result

    def upsert_secret(self, secret_id: str, values: dict) -> dict:
        """Create or update a secret."""
        return self._dp_put(f"/secrets/{secret_id}", {"values": values})

    def delete_secret(self, secret_id: str) -> None:
        """Delete a secret."""
        self._dp_delete(f"/secrets/{secret_id}")

    # -------------------------------------------------------------------------
    # Content Packages — data plane
    # -------------------------------------------------------------------------

    def list_content_packages(self) -> list:
        """List content packages."""
        return self._dp_get("/contentpackages")

    # -------------------------------------------------------------------------
    # SSH — WebSocket interactive shell
    # -------------------------------------------------------------------------

    def ssh(self, sandbox_id: str, sandbox_group: str, command: str = "/bin/bash",
            resource_group: str | None = None) -> None:
        """Open an interactive shell in a sandbox via WebSocket.

        Takes over stdin/stdout — use in a terminal context.
        Press Ctrl+D to exit.
        """
        import websocket

        import base64
        import json
        import os
        import sys
        import threading

        token = get_token(self._credential, DATA_PLANE_SCOPE)
        rg = self._rg(resource_group)
        ws_url = (
            f"wss://management.azuredevcompute.io"
            f"/subscriptions/{self.subscription_id}"
            f"/resourceGroups/{rg}"
            f"/sandboxGroups/{sandbox_group}"
            f"/sandboxes/{sandbox_id}/exec/stream"
        )

        cols = os.get_terminal_size().columns if sys.stdout.isatty() else 80
        rows = os.get_terminal_size().lines if sys.stdout.isatty() else 24

        ws = websocket.WebSocket()
        ws.connect(ws_url, header={"Authorization": f"Bearer {token}"})

        ws.send(json.dumps({
            "type": "start",
            "start": {
                "command": command,
                "environment": {"TERM": "xterm-256color", "LANG": "C.UTF-8"},
                "tty": True, "stdin": True, "height": rows, "width": cols,
            },
        }))

        # Raw terminal mode
        raw_cleanup = None
        if sys.platform != "win32" and sys.stdin.isatty():
            import tty
            import termios
            old = termios.tcgetattr(sys.stdin)
            tty.setraw(sys.stdin.fileno())
            raw_cleanup = lambda: termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old)

        stop = threading.Event()

        def _read_ws():
            try:
                while not stop.is_set():
                    data = ws.recv()
                    if not data:
                        break
                    msg = json.loads(data)
                    if msg.get("type") in ("stdout", "stderr"):
                        out = base64.b64decode(msg.get("data", ""))
                        stream = sys.stdout.buffer if msg["type"] == "stdout" else sys.stderr.buffer
                        stream.write(out)
                        stream.flush()
                    elif msg.get("type") == "exit_code":
                        break
                    elif msg.get("type") == "error":
                        sys.stderr.write(f"\nError: {msg}\n")
                        break
            except Exception:
                pass
            finally:
                stop.set()

        def _read_stdin():
            try:
                if sys.platform == "win32":
                    import msvcrt
                    while not stop.is_set():
                        ch = msvcrt.getch()
                        if ch in (b'\x04', b'\x1a'):
                            break
                        if ch in (b'\x00', b'\xe0'):
                            ch2 = msvcrt.getch()
                            ch = ch + ch2
                        ws.send(json.dumps({"type": "stdin", "data": base64.b64encode(ch).decode()}))
                else:
                    while not stop.is_set():
                        ch = sys.stdin.buffer.read(1)
                        if not ch or ch == b'\x04':
                            break
                        ws.send(json.dumps({"type": "stdin", "data": base64.b64encode(ch).decode()}))
            except Exception:
                pass
            finally:
                stop.set()

        t_ws = threading.Thread(target=_read_ws, daemon=True)
        t_in = threading.Thread(target=_read_stdin, daemon=True)
        t_ws.start()
        t_in.start()

        try:
            t_ws.join()
        except KeyboardInterrupt:
            pass
        finally:
            stop.set()
            if raw_cleanup:
                raw_cleanup()
            ws.close()

    # -------------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------------

    def close(self) -> None:
        self._dp.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

